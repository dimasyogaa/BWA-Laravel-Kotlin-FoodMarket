package com.bagicode.foodmarketkotlin.base

interface BasePresenter {

    fun subscribe()

    fun unSubscribe()
}