package com.bagicode.foodmarketkotlin.base

interface BaseView {

    fun showLoading()
    fun dismissLoading()
}