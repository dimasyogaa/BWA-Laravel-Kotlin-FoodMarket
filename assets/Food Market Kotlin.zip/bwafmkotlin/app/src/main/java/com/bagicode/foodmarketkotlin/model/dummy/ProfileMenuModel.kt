package com.bagicode.foodmarketkotlin.model.dummy

class ProfileMenuModel (title:String) {

    var title = ""

    init {
        this.title = title
    }

}